//============================================= 1
/*for(var x=1;x<=5;x++){
    document.write(x+" hello world<br>");
}*/


//============================================= 2
/*
for(x=1;x<=10;x++){
    document.write(x+"<br>");
}*/



//============================================= 3
/*var tableNo=prompt("Enter Table No.");
tableLength=prompt("table length");
for(var x=1;x<=tableLength;x++){
    document.write(tableNo+" x "+x+" = "+ tableNo*x+"<br>")
}*/

//============================================= 4

/*var A = ["Nokia","Samsung", "Apple", "Sony", "Huawei"];
for(var x=1;x<=5;x++){
    document.write(A.pop()+"<br>");
}*/


//============================================= 5

/*
var numOfItem=+prompt("number of item");
var items=[];
console.log(numOfItem);
for(var x=0; x<numOfItem; x++){
    //console.log(x);
    items[x]=prompt("item no."+x +" is");
}
console.log(items);*/

//============================================= 6
/*
document.write("Countning<br>");
document.write("------------------<br>");
for(var x=1;x<=10;x++){
    document.write(x+"<br>")
}

document.write("Reverse Countning<br>");
document.write("------------------------------<br>");
for(var x=10;x>=1;x--){
    document.write(x+"<br>")
}
document.write("Even Numbers<br>");
document.write("----------------------<br>");
for(var x=2;x<=20;x=x+2){
    document.write(x+"<br>")
}

document.write("Odd Numbers<br>");
document.write("-----------------<br>");
for(var x=1;x<=20;x=x+2){
    document.write(x+"<br>")
}

document.write("Series<br>");
document.write("----------------------<br>");
for(var x=2;x<=20;x=x+2){
    document.write(x+"k<br>")
}
*/


//============================================= 7
var product=["cake","pastry","chips","cookie"];
//console.log(product[2]);
var demand=prompt("what do you want sir/ mam?");
var found = false;
for(var x=0;x<product.length;x++){
    if(product[x]== demand){
        found=true;
        document.write(demand + " is availiable");
        break;
    }
    //console.log(product[x]);
}
if(!found){
    document.write(demand+" not in our list");
}
console.log(product[x]);


//============================================= 8

/*var a=[24,53,78,91,12];
for(var x=1; x<=5;x++){
    //console.log(a.pop())
    if(24> 53> 78> 91< 12){
        console.log("aa");
    }
}*/

//============================================= 9

/*
for(var x=5;x<=100;x=x+5){
    document.write(x+"<br>");
}
*/



//============================================= 10

/*
var students = ["Ali", "Sami", "Taha", "Inam"];
var scores = [58, 73, 89, 90];
for(var x=0;x<students.length;x++){
    document.write("<table border='1' width='200'><tr>");
    document.write("<td>"+students[x]+"</td>");
    document.write("<td>"+scores[x]+"</td>");
        document.write("</tr></table>");
}
*/
//============================================= 11

/*
var scores = [12, 45, 3, 22, 34, 50];
var userno=3;
for(var x=0;x<scores.length;x++){

    if(!scores==userno){
        break;
    }else{
        document.write(scores[x]+"<br>");
    }
}*/



//============================================= 12






//============================================= 13
