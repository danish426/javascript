var arr=['j','l','p','a','f','j','l','p','pak'];
var num=[891,591,521,10951,100];
console.log(num);
console.log(arr);

// arr.splice(starting index,no. of delets index,set value......);
/*
arr.splice(2,3,25);
console.log(arr);
*/

/*
var val=[1,2,3,4];
val.splice(0,1,"a");
console.log(val);*/

//==================== splice end==============



//var x=arr.slice(starrting index,no. of index );
/*
var x=arr.slice(0,3);
console.log(x);
console.log(arr);
 var val=['a','b','c','d','e'];
var y=val.slice(1,4);
console.log(y);*/

/*num.sort(function(a,b){return b-a});
//num.reverse() for reverse index no. as define;
//num.reverse();
console.log(num);*/

//arr.splice(0,1);
/*
arr.sort();
arr.splice(2,2);
var a=arr.slice(6,7);
console.log(arr);
console.log(a);*/

